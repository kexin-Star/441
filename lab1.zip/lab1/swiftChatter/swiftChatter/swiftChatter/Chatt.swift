//
//  Chatt.swift
//  swiftChatter
//
//  Created by kexin on 5/22/22.
//

struct Chatt {
    var username: String?
    var message: String?
    var timestamp: String?
}
